const Expense = require("../models/expense.model");
const { AppError } = require("../utils/errorHandler");

async function createExpense(userId, expenseData) {
  const { title, amount, category, date, note } = expenseData;
  const expense = await Expense.create({
    title,
    amount,
    category,
    date,
    note,
    user: userId,
  });
  return expense;
}

async function getExpenses(userId) {
  const expenses = await Expense.find({ user: userId }).sort({ date: -1 });
  return expenses;
}

async function getExpenseById(expenseId, userId) {
  const expense = await Expense.findOne({
    _id: expenseId,
    user: userId,
  });
  if (!expense) throw new AppError(404, "Expense not found");
  return expense;
}

async function updateExpense(expenseId, userId, updatedData) {
  const expense = await Expense.findOne({
    _id: expenseId,
    user: userId,
  });
  if (!expense) throw new AppError(404, "Expense not found");

  Object.assign(expense, updatedData);
  await expense.save();

  return expense;
}

async function deleteExpense(expenseId, userId) {
  const expense = await Expense.findOneAndDelete({
    _id: expenseId,
    user: userId,
  });
  if (!expense) throw new AppError(404, "Expense not found");
  return;
}

module.exports = {
  createExpense,
  getExpenses,
  getExpenseById,
  updateExpense,
  deleteExpense,
};
